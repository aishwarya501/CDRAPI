﻿using CDRApi.Model;
using Microsoft.EntityFrameworkCore;

namespace CDRApi.Data
{
    public class CDRContext:DbContext
    {
        public CDRContext(DbContextOptions<CDRContext> options) : base(options) { }

        public DbSet<CDR> cdr { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CDR>().HasKey(c => c.id);
        }
    }
}
