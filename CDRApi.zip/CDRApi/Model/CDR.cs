﻿namespace CDRApi.Model
{
    public class CDR
    {
        public int id { get; set; }
        public string caller_id { get; set; }
        public string recipient { get; set; }
        public DateOnly call_date { get; set; }
        public TimeSpan end_time { get; set; }
        public int duration { get; set; }
        public decimal cost { get; set; }
        public string reference { get; set; }
        public string currency { get; set; }

    }
}
