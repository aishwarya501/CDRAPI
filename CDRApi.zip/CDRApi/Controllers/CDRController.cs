﻿using CDRApi.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using CsvHelper;
using System.Globalization;
using CDRApi.Model;
using Microsoft.EntityFrameworkCore;

namespace CDRApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CDRController : ControllerBase
    {
        private readonly string connectionstring;
        private readonly CDRContext _context;
        public CDRController(IConfiguration configuration, CDRContext context)
        {
            connectionstring = configuration["ConnectionStrings:DefaultConnection"] ?? "";
            _context = context;
        }

        [HttpPost("upload")]
        public async Task<ActionResult> UploadCDR(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest("No File selected");

            }
            try
            {

                using (var reader = new StreamReader(file.OpenReadStream()))
                {
                    using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
                    {
                        var records = csv.GetRecords<CDR>();
                        await _context.cdr.AddRangeAsync(records);
                        await _context.SaveChangesAsync();
                    }

                }
                return Ok("File Uploaded Successfully");

            }
            catch
            {
                return StatusCode(500, "error");
            }
        }



        [HttpGet("AverageCost")]
        public async Task<ActionResult<decimal>> GetAverageCallCost()

        {
            var averageCost = await _context.cdr.AverageAsync(c => c.cost);
            return Ok(averageCost);
        }

        [HttpGet("LongestCall")]
        public async Task<ActionResult<CDR>> GetLongestCall()
        {
            var longestCall = await _context.cdr.OrderByDescending(c => c.duration).FirstOrDefaultAsync();
            return Ok(longestCall);
        }

        [HttpGet("total-call-duration-by-caller")]
        public async Task<ActionResult<IEnumerable<CallerDuration>>> GetTotalCallDurationByCaller()

        {
            var result = await _context.cdr
                .GroupBy(c => c.caller_id)
                .Select(g => new CallerDuration { CallerId=g.Key, TotalDuratiobn =g.Sum(c => c.duration)})
                .ToListAsync();
            return Ok(result);
         
        }


        [HttpPost("filter")]
        public async Task<IActionResult> FilterCDRs(FilterCriteria criteria)
        {
            IQueryable<CDR> query = _context.cdr;

            switch (criteria.Condition)
            {
                case "Equals":
                    query = query.Where(c => EF.Property<string>(c, criteria.ColumnName) == criteria.Value);
                    break;
                case "GreaterThan":
                    query = query.Where(c => EF.Property<decimal>(c, criteria.ColumnName) > decimal.Parse(criteria.Value));
                    break;
                case "LessThan":
                    query = query.Where(c => EF.Property<decimal>(c, criteria.ColumnName) < decimal.Parse(criteria.Value));
                    break;
                case "Contains":
                    query = query.Where(c => EF.Property<string>(c, criteria.ColumnName).Contains(criteria.Value));
                    break;
                default:
                    return BadRequest("Invalid Condition");
            }

            var filteredResult = await query.ToListAsync();
            return Ok(filteredResult);
        }
    }
    public class FilterCriteria { 
    
    public string ColumnName { get; set; }
        public string Condition { get; set; }
        public string Value { get; set; }
    }

    public class CallerDuration
    {
        public string CallerId { get; set; }
        public int TotalDuratiobn{get;set;}
     
    }
}
